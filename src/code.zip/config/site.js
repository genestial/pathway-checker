export const site = {
  name: "PATHWAY Sustainability Checker",
  social: {
    facebook: "https://www.facebook.com/AsponConsultingLtd",
    linkedin: "https://www.linkedin.com/company/asponconsultingltd/",
  },
  links: {
    privacy: "/privacy",
    terms: "/terms",
    contact: "https://aspon.com.cy/contact-us/",
  },
};
